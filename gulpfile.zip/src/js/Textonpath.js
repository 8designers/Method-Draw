MD.TextOnPath = function(){
  console.log("hi")
}